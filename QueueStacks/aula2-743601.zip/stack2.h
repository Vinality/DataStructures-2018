#ifndef STACK2_H_
#define STACK2_H_
#include <stdlib.h>

typedef struct _pilha{
    int valor;
    struct _pilha *prox;
}no;

typedef struct {
    no *primeiro;
    int indiceparcial;
}pilha;

void createStack(pilha *p);

void destroyStack(pilha *p);

int emptyStack(pilha *p);

void popStack(pilha *p);

void pushStack(pilha *p, int v);

int stackSize(pilha *p);

int stackTop(pilha *p);

void printStack(pilha *p);

#endif
